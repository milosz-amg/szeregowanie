import sys

tasks_amount = int(sys.stdin.readline().strip('\n'))

tasks_length = []
nodes = []
for i in range(tasks_amount):
    task_ready, task_lengths = list(map(int, sys.stdin.readline().strip().split())) 
    tasks_length.append((i + 1, task_ready, task_lengths))
    nodes.append(i + 1)

original_tasks_length = tasks_length.copy()
tasks_length.sort(key=lambda x: x[1])

operations_amount = int(sys.stdin.readline().strip('\n'))

operations = []
for i in range(operations_amount):
    operation = tuple(map(int, sys.stdin.readline().strip().split())) 
    operations.append(operation)

sorted_nodes = []
nodes_without_prev = nodes.copy()
node_without_prev = int

while nodes_without_prev:
    for i in range(len(operations)):
        node_with_prev = int(operations[i][1])
        if node_with_prev in nodes_without_prev:
            nodes_without_prev.remove(node_with_prev)
    for i in range(len(tasks_length)):
        if tasks_length[i][0] in nodes_without_prev:
            node_without_prev = tasks_length[i][0]
            break
    sorted_nodes.append(node_without_prev)
    nodes_to_remove = node_without_prev
    operations = [op for op in operations if op[0] != node_without_prev]
    nodes_without_prev.remove(node_without_prev)
    nodes_without_prev = [node for node in nodes if node not in sorted_nodes]
    

#for node in sorted_nodes:
#    print(node)
#print(sorted_nodes)
total_time = 0
for node_index in sorted_nodes:
    total_time += max(0, original_tasks_length[node_index - 1][1] - total_time) + original_tasks_length[node_index - 1][2]
    #print(node_index, total_time)

#total_time = sum(tasks_length[node_index - 1][2] for node_index in sorted_nodes)
print(total_time)
